
import os
import joblib
import numpy as np
import pandas as pd
import tensorflow as tf


class DoWInferenceEngine:

    def __init__(self):

        # Project paths
        BASE_DIR = os.path.dirname(
            os.path.dirname(os.path.abspath(__file__))
        )

        PREPROCESSOR_PATH = os.path.join(
            BASE_DIR, "models", "preprocessor.joblib"
        )

        MODEL_PATH = os.path.join(
            BASE_DIR, "models", "selected_adaptive_model.keras"
        )

        print("Loading saved preprocessor...")

        self.preprocessor = joblib.load(
            PREPROCESSOR_PATH
        )

        print("Preprocessor loaded successfully.")

        print("\nLoading selected adaptive LSTM model...")

        self.model = tf.keras.models.load_model(
            MODEL_PATH,
            compile=False
        )

        print("LSTM model loaded successfully.")

        # Original raw input feature order
        self.feature_columns = [
            "RTT",
            "InvocationDelay",
            "ResponseDelay",
            "FunctionDuration",
            "ActiveFunctionsAtRequest",
            "ActiveFunctionsAtResponse",
            "maxcpu",
            "avgcpu",
            "p95maxcpu",
            "vmcorecountbucket",
            "vmmemorybucket",
            "InterArrivalTime",
            "FunctionInvocationsPerMinute",
            "InvocationsLast5Min",
            "TotalDelay",
            "TotalProcessingTime",
            "ActiveFunctionChange",
            "CPU_Spread",
            "functionTrigger",
            "vmcategory"
        ]

        # Verify model input shape
        print("\nMODEL INFORMATION")
        print("------------------------------")
        print("Model input shape:", self.model.input_shape)
        print("Model output shape:", self.model.output_shape)
        print("Expected sequence length: 30")
        print("Expected encoded features: 26")

        if self.model.input_shape[1:] != (30, 26):
            raise ValueError(
                "Model input shape does not match (30, 26)."
            )

        print("\nINFERENCE ENGINE INITIALIZED SUCCESSFULLY.")

    # --------------------------------------------------
    # PREPROCESS RAW EVENT
    # --------------------------------------------------

    def preprocess_event(self, raw_event):

        # Create DataFrame in original feature order
        event_df = pd.DataFrame(
            [raw_event],
            columns=self.feature_columns
        )

        # Apply saved preprocessing
        transformed = self.preprocessor.transform(
            event_df
        )

        # Convert sparse output if necessary
        if hasattr(transformed, "toarray"):
            transformed = transformed.toarray()

        transformed = np.asarray(
            transformed,
            dtype=np.float32
        )

        # Return 26 encoded features
        return transformed[0]

    # --------------------------------------------------
    # PREDICT FROM A 30-EVENT SEQUENCE
    # --------------------------------------------------

    def predict_sequence(self, sequence):

        sequence = np.asarray(
            sequence,
            dtype=np.float32
        )

        if sequence.shape != (30, 26):
            raise ValueError(
                f"Expected (30, 26), received {sequence.shape}"
            )

        # Add batch dimension
        model_input = np.expand_dims(
            sequence,
            axis=0
        )

        # Model prediction
        probability = self.model.predict(
            model_input,
            verbose=0
        )

        # Binary classification
        probability = float(
            np.asarray(probability).reshape(-1)[0]
        )

        prediction = 1 if probability >= 0.5 else 0

        result = {
            "prediction": prediction,
            "class": "DoW" if prediction == 1 else "Normal",
            "probability": probability
        }

        return result


# ======================================================
# TEST MODEL AND PREPROCESSOR LOADING
# ======================================================

def main():

    print("=" * 55)
    print("DoW INFERENCE ENGINE TEST")
    print("=" * 55)

    engine = DoWInferenceEngine()

    print("\nTESTING PREPROCESSOR...")

    # Display expected input feature count
    print(
        "Raw input features:",
        len(engine.feature_columns)
    )

    print(
        "Encoded features:",
        len(engine.preprocessor.get_feature_names_out())
    )

    print("\nTESTING MODEL...")

    print(
        "Model input:",
        engine.model.input_shape
    )

    print(
        "Model output:",
        engine.model.output_shape
    )

    print("\nPHASE 5 ARTIFACT LOADING TEST PASSED.")


if __name__ == "__main__":
    main()
