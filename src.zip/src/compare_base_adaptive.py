
import os
import numpy as np
import pandas as pd

from tensorflow.keras.models import load_model
from sklearn.metrics import (
    accuracy_score,
    precision_score,
    recall_score,
    f1_score,
    confusion_matrix,
    classification_report
)

print("=" * 60)
print("PHASE 6.4 - BASE VS ADAPTIVE MODEL COMPARISON")
print("=" * 60)

# Step 1: Load the same held-out test data
X_test = np.load(
    "data/processed/sequences/X_test.npy"
)

y_test = np.load(
    "data/processed/sequences/y_test.npy"
)

y_test = y_test.reshape(-1)

print("\nTest dataset loaded.")
print("Test sequences:", len(X_test))
print("Sequence shape:", X_test.shape)

# Step 2: Load the two existing models
base_model = load_model(
    "models/selected_base_model.keras"
)

adaptive_model = load_model(
    "models/selected_adaptive_model.keras"
)

print("\nBoth models loaded successfully.")

# Step 3: Evaluate each model
def evaluate_model(model, model_name):

    probabilities = model.predict(
        X_test,
        batch_size=256,
        verbose=0
    ).reshape(-1)

    predictions = (probabilities >= 0.5).astype(int)

    accuracy = accuracy_score(
        y_test, predictions
    )

    precision = precision_score(
        y_test, predictions, zero_division=0
    )

    recall = recall_score(
        y_test, predictions, zero_division=0
    )

    f1 = f1_score(
        y_test, predictions, zero_division=0
    )

    print("\n" + "-" * 50)
    print(model_name)
    print("-" * 50)

    print("Accuracy: ", round(accuracy, 4))
    print("Precision:", round(precision, 4))
    print("Recall:   ", round(recall, 4))
    print("F1 Score: ", round(f1, 4))

    print("\nConfusion Matrix:")
    print(confusion_matrix(y_test, predictions))

    print("\nClassification Report:")
    print(
        classification_report(
            y_test,
            predictions,
            target_names=["Normal", "DoW"],
            zero_division=0
        )
    )

    return {
        "Model": model_name,
        "Accuracy": accuracy,
        "Precision": precision,
        "Recall": recall,
        "F1_Score": f1
    }


# Step 4: Evaluate both models
base_results = evaluate_model(
    base_model,
    "BASE MODEL"
)

adaptive_results = evaluate_model(
    adaptive_model,
    "ADAPTIVE MODEL"
)

# Step 5: Compare the results
comparison_df = pd.DataFrame([
    base_results,
    adaptive_results
])

print("\n" + "=" * 60)
print("FINAL MODEL COMPARISON")
print("=" * 60)

print(
    comparison_df.to_string(
        index=False,
        float_format=lambda x: f"{x:.4f}"
    )
)

# Step 6: Calculate improvement
print("\nADAPTIVE MODEL IMPROVEMENT")

for metric in [
    "Accuracy",
    "Precision",
    "Recall",
    "F1_Score"
]:

    improvement = (
        adaptive_results[metric]
        - base_results[metric]
    ) * 100

    print(
        metric,
        ":",
        round(improvement, 2),
        "percentage points"
    )

# Step 7: Save comparison results
os.makedirs("results", exist_ok=True)

comparison_df.to_csv(
    "results/phase_6_4_model_comparison.csv",
    index=False
)

print("\nComparison report saved successfully.")
print("\nPHASE 6.4 TEST COMPLETED.")
