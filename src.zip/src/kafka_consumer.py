
# %% [markdown]
# ============================================================
# PHASE 3: KAFKA CONSUMER
# Project: Denial-of-Wallet Attack Detection
# Purpose: Receive workload events from Kafka
# ============================================================

# %% [markdown]
# STEP 1: IMPORT REQUIRED LIBRARIES

# %%
import json
from kafka import KafkaConsumer


# %% [markdown]
# STEP 2: CONFIGURATION

# %%
KAFKA_SERVER = "localhost:9092"
TOPIC_NAME = "workload-events"

MAX_MESSAGES = 10


# %% [markdown]
# STEP 3: CREATE KAFKA CONSUMER

# %%
def create_kafka_consumer():

    consumer = KafkaConsumer(
        TOPIC_NAME,
        bootstrap_servers=KAFKA_SERVER,

        # Convert JSON messages into Python dictionaries
        value_deserializer=lambda message: json.loads(
            message.decode("utf-8")
        ),

        # Read existing messages from the beginning
        auto_offset_reset="earliest",

        # Use a new consumer group for this test
        group_id="dow-stream-consumer-test",

        enable_auto_commit=True
    )

    print("Connected to Kafka successfully.")

    return consumer


# %% [markdown]
# STEP 4: RECEIVE WORKLOAD EVENTS

# %%
def receive_workload_events(consumer):

    total_received = 0

    print("\nReceiving workload events...\n")

    try:

        while total_received < MAX_MESSAGES:

            records = consumer.poll(timeout_ms=1000)

            for partition, messages in records.items():

                for message in messages:

                    event = message.value

                    total_received += 1

                    print(
                        f"Event {total_received} received | "
                        f"Partition: {message.partition} | "
                        f"Offset: {message.offset} | "
                        f"FunctionId: {event.get('FunctionId')} | "
                        f"Trigger: {event.get('functionTrigger')} | "
                        f"Bot: {event.get('bot')}"
                    )

                    if total_received >= MAX_MESSAGES:
                        break

                if total_received >= MAX_MESSAGES:
                    break

        print("\nTotal events received:", total_received)

    except KeyboardInterrupt:

        print("\nConsumer interrupted.")


# %% [markdown]
# STEP 5: MAIN EXECUTION

# %%
def main():

    consumer = None

    try:

        consumer = create_kafka_consumer()

        receive_workload_events(consumer)

        print("\nKAFKA CONSUMER COMPLETED SUCCESSFULLY.")

    finally:

        if consumer is not None:
            consumer.close()

            print("Kafka consumer connection closed.")


# %% [markdown]
# STEP 6: RUN THE PROGRAM

# %%
if __name__ == "__main__":
    main()
