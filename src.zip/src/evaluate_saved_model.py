import numpy as np
from tensorflow.keras.models import load_model
from sklearn.metrics import (
    accuracy_score,
    precision_score,
    recall_score,
    f1_score,
    confusion_matrix,
    classification_report
)

# Load test sequences and labels
X_test = np.load("data/processed/sequences/X_test.npy")
y_test = np.load("data/processed/sequences/y_test.npy")

# Load the already trained model
model = load_model("models/selected_adaptive_model.keras")

print("\nMODEL AND DATA INFORMATION")
print("------------------------------")
print("Test sequences:", X_test.shape)
print("Test labels:", y_test.shape)
print("Model input:", model.input_shape)

# Predict in batches
probabilities = model.predict(
    X_test,
    batch_size=256,
    verbose=1
)

# Convert probabilities into class predictions
y_pred = (probabilities.reshape(-1) >= 0.5).astype(int)

# Calculate metrics
accuracy = accuracy_score(y_test, y_pred)
precision = precision_score(y_test, y_pred, zero_division=0)
recall = recall_score(y_test, y_pred, zero_division=0)
f1 = f1_score(y_test, y_pred, zero_division=0)

print("\n" + "=" * 55)
print("HELD-OUT TEST RESULTS")
print("=" * 55)

print(f"Accuracy:  {accuracy:.4f}")
print(f"Precision: {precision:.4f}")
print(f"Recall:    {recall:.4f}")
print(f"F1 Score:  {f1:.4f}")

print("\nConfusion Matrix:")
print(confusion_matrix(y_test, y_pred))

print("\nClassification Report:")
print(
    classification_report(
        y_test,
        y_pred,
        target_names=["Normal", "DoW"],
        zero_division=0
    )
)

print("\nPHASE 5.4 TEST COMPLETED.")