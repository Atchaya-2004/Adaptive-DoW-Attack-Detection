
import os
from collections import defaultdict, deque

import numpy as np
import pandas as pd

from sklearn.metrics import (
    accuracy_score,
    precision_score,
    recall_score,
    f1_score,
    confusion_matrix,
    classification_report
)

from inference_engine import DoWInferenceEngine
from sequence_builder import SequenceBuilder


# ============================================================
# 1. PROJECT PATHS
# ============================================================

BASE_DIR = os.path.dirname(
    os.path.dirname(os.path.abspath(__file__))
)

DATA_PATH = os.path.join(
    BASE_DIR, "data", "raw", "dataset.csv"
)


print("=" * 60)
print("PHASE 5.3 - REAL DATA INFERENCE AND VALIDATION")
print("=" * 60)


# ============================================================
# 2. LOAD DATASET
# ============================================================

print("\nLoading dataset...")

df = pd.read_csv(DATA_PATH)

df["timestamp"] = pd.to_datetime(
    df["timestamp"],
    utc=True,
    errors="coerce"
)

df = df.dropna(subset=["timestamp"])

df = df.sort_values(
    ["timestamp", "Id"]
).reset_index(drop=True)

# Use first 5000 chronological events for testing
df = df.head(5000).copy()

print("Events loaded:", len(df))


# ============================================================
# 3. INITIALIZE INFERENCE ENGINE
# ============================================================

print("\nLoading inference engine...")

engine = DoWInferenceEngine()

print("Inference engine ready.")


# ============================================================
# 4. INITIALIZE SEQUENCE BUILDER
# ============================================================

sequence_builder = SequenceBuilder(
    sequence_length=30,
    max_time_gap=3600
)

print("Sequence builder ready.")


# ============================================================
# 5. TEMPORAL FEATURE TRACKING
# ============================================================

previous_timestamp = {}

minute_tracking = {}

recent_events = defaultdict(deque)


# ============================================================
# 6. STORE PREDICTIONS AND ACTUAL LABELS
# ============================================================

actual_labels = []

predicted_labels = []

predictions = []

sequence_count = 0


# ============================================================
# 7. PROCESS REAL WORKLOAD EVENTS
# ============================================================

print("\nProcessing real workload events...")


for index, row in df.iterrows():

    event = row.to_dict()

    function_id = event["FunctionId"]

    timestamp = event["timestamp"]


    # --------------------------------------------------------
    # A. InterArrivalTime
    # --------------------------------------------------------

    if function_id in previous_timestamp:

        inter_arrival = (
            timestamp - previous_timestamp[function_id]
        ).total_seconds()

    else:

        inter_arrival = 0.0

    previous_timestamp[function_id] = timestamp

    event["InterArrivalTime"] = inter_arrival


    # --------------------------------------------------------
    # B. FunctionInvocationsPerMinute
    # --------------------------------------------------------

    current_minute = timestamp.floor("min")

    tracking_key = (
        function_id,
        current_minute
    )

    if tracking_key not in minute_tracking:

        minute_tracking[tracking_key] = 0

    minute_tracking[tracking_key] += 1

    event["FunctionInvocationsPerMinute"] = (
        minute_tracking[tracking_key]
    )


    # --------------------------------------------------------
    # C. InvocationsLast5Min
    # --------------------------------------------------------

    event_queue = recent_events[function_id]

    event_queue.append(timestamp)

    while (
        event_queue
        and (
            timestamp - event_queue[0]
        ).total_seconds() > 300
    ):

        event_queue.popleft()

    event["InvocationsLast5Min"] = len(event_queue)


    # --------------------------------------------------------
    # D. TotalDelay
    # --------------------------------------------------------

    event["TotalDelay"] = (
        float(event["InvocationDelay"])
        + float(event["ResponseDelay"])
    )


    # --------------------------------------------------------
    # E. TotalProcessingTime
    # --------------------------------------------------------

    event["TotalProcessingTime"] = (
        float(event["InvocationDelay"])
        + float(event["FunctionDuration"])
        + float(event["ResponseDelay"])
    )


    # --------------------------------------------------------
    # F. ActiveFunctionChange
    # --------------------------------------------------------

    event["ActiveFunctionChange"] = (
        float(event["ActiveFunctionsAtResponse"])
        - float(event["ActiveFunctionsAtRequest"])
    )


    # --------------------------------------------------------
    # G. CPU_Spread
    # --------------------------------------------------------

    event["CPU_Spread"] = (
        float(event["maxcpu"])
        - float(event["avgcpu"])
    )


    # --------------------------------------------------------
    # H. PREPROCESS 20 FEATURES INTO 26 FEATURES
    # --------------------------------------------------------

    processed_features = engine.preprocess_event(event)


    # --------------------------------------------------------
    # I. KEEP ACTUAL LABEL SEPARATELY
    # --------------------------------------------------------

    actual_label = int(event["bot"])


    # --------------------------------------------------------
    # J. BUILD 30-EVENT SEQUENCE
    # --------------------------------------------------------

    result = sequence_builder.add_event(
        function_id=function_id,
        timestamp=timestamp,
        processed_features=processed_features,
        label=actual_label
    )


    # --------------------------------------------------------
    # K. GENERATE MODEL PREDICTION
    # --------------------------------------------------------

    if result is not None:

        sequence, sequence_label = result

        prediction = engine.predict_sequence(sequence)

        actual_labels.append(int(sequence_label))

        predicted_labels.append(
            prediction["prediction"]
        )

        predictions.append(prediction)

        sequence_count += 1


        # Display only first 10 predictions

        if sequence_count <= 10:

            print(
                "Sequence:", sequence_count,
                "| Prediction:", prediction["class"],
                "| DoW Probability:",
                round(prediction["probability"], 4)
            )


# ============================================================
# 8. INFERENCE RESULTS
# ============================================================

print("\n" + "=" * 60)

print("REAL DATA INFERENCE RESULTS")

print("=" * 60)

print("Events processed:", len(df))

print("Sequences created:", sequence_count)


if predictions:

    dow_count = sum(
        1 for item in predictions
        if item["prediction"] == 1
    )

    normal_count = (
        len(predictions) - dow_count
    )

    print("Normal predictions:", normal_count)

    print("DoW predictions:", dow_count)

    print(
        "DoW prediction percentage:",
        round(
            dow_count / len(predictions) * 100,
            2
        ),
        "%"
    )


# ============================================================
# 9. MODEL VALIDATION METRICS
# ============================================================

if actual_labels:

    print("\n" + "=" * 60)

    print("MODEL VALIDATION METRICS")

    print("=" * 60)


    accuracy = accuracy_score(
        actual_labels,
        predicted_labels
    )

    precision = precision_score(
        actual_labels,
        predicted_labels,
        zero_division=0
    )

    recall = recall_score(
        actual_labels,
        predicted_labels,
        zero_division=0
    )

    f1 = f1_score(
        actual_labels,
        predicted_labels,
        zero_division=0
    )


    print("Accuracy:", round(accuracy, 4))

    print("Precision:", round(precision, 4))

    print("Recall:", round(recall, 4))

    print("F1 Score:", round(f1, 4))


    # --------------------------------------------------------
    # CONFUSION MATRIX
    # --------------------------------------------------------

    print("\nConfusion Matrix:")

    cm = confusion_matrix(
        actual_labels,
        predicted_labels,
        labels=[0, 1]
    )

    print(cm)


    # --------------------------------------------------------
    # CLASSIFICATION REPORT
    # --------------------------------------------------------

    print("\nClassification Report:")

    print(
        classification_report(
            actual_labels,
            predicted_labels,
            labels=[0, 1],
            target_names=["Normal", "DoW"],
            zero_division=0
        )
    )


else:

    print("\nNo complete sequences available for validation.")


# ============================================================
# 10. COMPLETION
# ============================================================

print("\n" + "=" * 60)

print("PHASE 5.3 TEST COMPLETED.")

print("=" * 60)
