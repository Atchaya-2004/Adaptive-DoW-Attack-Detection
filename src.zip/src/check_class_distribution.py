import pandas as pd

df = pd.read_csv("data/raw/dataset.csv")

df["timestamp"] = pd.to_datetime(
    df["timestamp"],
    utc=True,
    errors="coerce"
)

df = df.dropna(subset=["timestamp"])

df = df.sort_values(
    ["timestamp", "Id"]
).reset_index(drop=True)

print("\nFULL DATASET CLASS DISTRIBUTION")
print(df["bot"].value_counts())

print("\nFIRST 5000 EVENTS CLASS DISTRIBUTION")
print(df.head(5000)["bot"].value_counts())

print("\nCLASS DISTRIBUTION IN PERCENTAGE")
print(
    df["bot"].value_counts(normalize=True) * 100
)