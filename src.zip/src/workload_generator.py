
# %% [markdown]
# # PHASE 2: WORKLOAD EVENT GENERATION
#
# ## Project
# Adaptive Temporal Detection of Denial-of-Wallet (DoW)
# Attacks in Serverless Cloud Environments
#
# ## Objective
# Read historical serverless workload records and replay
# them one at a time in chronological order.
#
# ## Input
# data/raw/dataset.csv
#
# ## Output
# A sequence of workload events that can later be
# published to a Kafka topic.
#
# ## Important
# This phase performs historical data replay.
# It does not generate real cloud traffic or new attack data.


# %% [markdown]
# ## STEP 1: IMPORT REQUIRED LIBRARIES
#
# Import the Python libraries required for:
# - Dataset handling
# - Timestamp processing
# - Replay delays


# %%
import pandas as pd
import time


# %% [markdown]
# ## STEP 2: DEFINE PROJECT CONFIGURATION
#
# DATA_PATH:
# Location of the original workload dataset.
#
# MAX_EVENTS:
# Number of events to replay during the initial test.
# Use None to replay all available events.
#
# REPLAY_DELAY_SECONDS:
# Delay between consecutive events.
# 0 means replay as fast as possible.
# 1 means wait one second between events.


# %%
DATA_PATH = "data/raw/dataset.csv"

MAX_EVENTS = 10

REPLAY_DELAY_SECONDS = 0.0


# %% [markdown]
# ## STEP 3: LOAD THE ORIGINAL DATASET
#
# Read the historical workload dataset using Pandas.
#
# Display:
# - Total number of records
# - Number of columns
# - First five records


# %%
def load_dataset(file_path):

    print("\nLoading workload dataset...")

    df = pd.read_csv(file_path)

    print("\nDATASET LOADED SUCCESSFULLY")

    print("Total records:", len(df))
    print("Total columns:", len(df.columns))

    print("\nFirst five records:")
    print(df.head())

    return df


# %% [markdown]
# ## STEP 4: VALIDATE DATASET COLUMNS
#
# Check whether the dataset contains the timestamp
# column required for chronological event replay.
#
# Stop execution if the column is missing.


# %%
def validate_dataset(df):

    required_columns = ["timestamp"]

    missing_columns = []

    for column in required_columns:

        if column not in df.columns:
            missing_columns.append(column)

    if len(missing_columns) > 0:

        raise ValueError(
            "Missing required columns: "
            + str(missing_columns)
        )

    print("\nDATASET VALIDATION SUCCESSFUL")

    print("Required columns are available.")


# %% [markdown]
# ## STEP 5: PROCESS TIMESTAMPS
#
# Convert timestamp values into Pandas datetime format.
#
# Invalid timestamps are identified and removed because
# they cannot be placed reliably in chronological order.
#
# UTC is used to keep timestamp interpretation consistent.


# %%
def process_timestamps(df):

    df = df.copy()

    original_count = len(df)

    df["timestamp"] = pd.to_datetime(
        df["timestamp"],
        utc=True,
        errors="coerce"
    )

    invalid_count = df["timestamp"].isna().sum()

    df = df.dropna(subset=["timestamp"])

    print("\nTIMESTAMP PROCESSING COMPLETED")

    print("Original records:", original_count)
    print("Invalid timestamps:", invalid_count)
    print("Valid records:", len(df))

    return df


# %% [markdown]
# ## STEP 6: SORT EVENTS CHRONOLOGICALLY
#
# Arrange workload events from earliest to latest
# using their timestamp.
#
# Stable sorting preserves the original order of records
# when two or more events have identical timestamps.


# %%
def sort_events(df):

    df = df.sort_values(
        by="timestamp",
        ascending=True,
        kind="stable"
    )

    df = df.reset_index(drop=True)

    print("\nCHRONOLOGICAL SORTING COMPLETED")

    print("\nFirst five timestamps:")

    print(df["timestamp"].head())

    return df


# %% [markdown]
# ## STEP 7: CONVERT DATASET ROWS INTO EVENTS
#
# Each dataset row represents one workload event.
#
# Convert each row into a Python dictionary.
#
# Preserve all original columns, including the bot label.
# Do not change or reinterpret the original labels here.
#
# Convert missing values to None and timestamps to
# ISO-format strings for easier future JSON/Kafka use.


# %%
def convert_row_to_event(row):

    event = row.to_dict()

    for column, value in event.items():

        if pd.isna(value):

            event[column] = None

        elif isinstance(value, pd.Timestamp):

            event[column] = value.isoformat()

    return event


# %% [markdown]
# ## STEP 8: CREATE THE WORKLOAD EVENT REPLAY GENERATOR
#
# A generator produces one event at a time instead of
# loading a second complete copy of the dataset into memory.
#
# delay_seconds controls the optional pause between events.
#
# limit controls how many events are replayed.
#
# This function can later be reused by the Kafka producer.


# %%
def replay_events(df, limit=None, delay_seconds=0.0):

    if delay_seconds < 0:

        raise ValueError(
            "Replay delay cannot be negative."
        )

    total_events = len(df)

    if limit is not None:

        total_events = min(limit, total_events)

    print("\nSTARTING WORKLOAD EVENT REPLAY")

    print("Events to replay:", total_events)

    for index, (_, row) in enumerate(
        df.iterrows(),
        start=1
    ):

        if limit is not None and index > limit:

            break

        event = convert_row_to_event(row)

        print(
            f"\nEvent {index}/{total_events}"
        )

        print("Timestamp:", event["timestamp"])

        print("Function ID:", event.get("FunctionId"))

        print("Function Trigger:", event.get("functionTrigger"))

        print("Bot Label:", event.get("bot"))

        yield event

        if delay_seconds > 0 and index < total_events:

            time.sleep(delay_seconds)

    print("\nWORKLOAD EVENT REPLAY COMPLETED")


# %% [markdown]
# ## STEP 9: DISPLAY REPLAY SUMMARY
#
# Display the number of original records and the
# distribution of the original bot labels.
#
# These are dataset labels. Their interpretation as
# DoW/normal must follow the original project methodology.


# %%
def display_summary(df):

    print("\n" + "=" * 50)

    print("WORKLOAD DATASET SUMMARY")

    print("=" * 50)

    print("Total valid records:", len(df))

    print("\nBot label distribution:")

    if "bot" in df.columns:

        print(
            df["bot"].value_counts(dropna=False)
        )

    else:

        print("Bot column is not available.")


# %% [markdown]
# ## STEP 10: MAIN EXECUTION
#
# Run all the above processes in the correct order:
#
# 1. Load dataset
# 2. Validate columns
# 3. Process timestamps
# 4. Sort events
# 5. Display summary
# 6. Replay workload events
#
# The initial test replays only the first ten events.
# The replay function can later be connected to Kafka.


# %%
def main():

    # Load dataset
    df = load_dataset(DATA_PATH)

    # Validate required columns
    validate_dataset(df)

    # Process timestamps
    df = process_timestamps(df)

    # Sort events chronologically
    df = sort_events(df)

    # Display dataset summary
    display_summary(df)

    # Replay workload events
    event_generator = replay_events(
        df,
        limit=MAX_EVENTS,
        delay_seconds=REPLAY_DELAY_SECONDS
    )

    # Consume the generated events
    for event in event_generator:

        pass

    print("\nPHASE 2 INITIAL REPLAY TEST COMPLETED")


# %% [markdown]
# ## END OF PHASE 2: WORKLOAD EVENT GENERATION
#
# Expected result:
# - Dataset loaded successfully
# - Timestamps processed
# - Events sorted chronologically
# - Individual events generated
# - Original labels preserved
#
# Next phase:
# Kafka producer and consumer integration.


# %%
if __name__ == "__main__":

    main()

# %%
