
import streamlit as st
import pandas as pd
import plotly.express as px
from pathlib import Path

# --------------------------------------------------
# 1. PAGE CONFIGURATION
# --------------------------------------------------

st.set_page_config(
    page_title="Denial-of-Wallet Detection Dashboard",
    page_icon="🛡️",
    layout="wide"
)

BASE_DIR = Path(__file__).resolve().parent.parent
RESULTS_DIR = BASE_DIR / "results"

PREDICTIONS_FILE = RESULTS_DIR / "streaming_predictions.csv"
DRIFT_FILE = RESULTS_DIR / "feature_drift_report.csv"
MODEL_FILE = RESULTS_DIR / "phase_6_4_model_comparison.csv"


# --------------------------------------------------
# 2. LOAD DATA
# --------------------------------------------------

@st.cache_data
def load_data():
    predictions = pd.read_csv(PREDICTIONS_FILE)
    drift = pd.read_csv(DRIFT_FILE)
    model_comparison = pd.read_csv(MODEL_FILE)

    predictions["timestamp"] = pd.to_datetime(
        predictions["timestamp"],
        errors="coerce",
        utc=True
    )

    predictions["probability"] = pd.to_numeric(
        predictions["probability"],
        errors="coerce"
    )

    predictions["prediction"] = (
        predictions["prediction"].astype(str).str.strip()
    )

    return predictions, drift, model_comparison


st.sidebar.title("Dashboard Controls")

if st.sidebar.button("Refresh Dashboard"):
    st.cache_data.clear()

try:
    predictions, drift, model_comparison = load_data()

except Exception as error:
    st.error(f"Unable to load project result files: {error}")
    st.info("Check that the required CSV files are available in the results folder.")
    st.stop()


# --------------------------------------------------
# 3. DASHBOARD HEADER
# --------------------------------------------------

st.title("🛡️ Denial-of-Wallet Attack Detection")
st.subheader("Adaptive Temporal Detection in Serverless Cloud Environments")

st.caption(
    "Real-time-style monitoring using simulated Kafka workload replay "
    "and saved machine learning model predictions."
)

st.divider()


# --------------------------------------------------
# 4. STREAMING OVERVIEW
# --------------------------------------------------

total_predictions = len(predictions)

dow_count = (
    predictions["prediction"].str.lower() == "dow"
).sum()

normal_count = total_predictions - dow_count

dow_percentage = (
    dow_count / total_predictions * 100
    if total_predictions > 0 else 0
)

average_probability = predictions["probability"].mean()

st.header("1. Streaming Prediction Overview")

col1, col2, col3, col4 = st.columns(4)

col1.metric("Total Predictions", f"{total_predictions:,}")
col2.metric("Normal Predictions", f"{normal_count:,}")
col3.metric("DoW Alerts", f"{dow_count:,}")
col4.metric("DoW Prediction Rate", f"{dow_percentage:.2f}%")

if pd.notna(average_probability):
    st.metric(
        "Average Prediction Probability",
        f"{average_probability:.4f}"
    )

st.divider()


# --------------------------------------------------
# 5. PREDICTION DISTRIBUTION
# --------------------------------------------------

st.header("2. Prediction Distribution")

distribution = pd.DataFrame({
    "Prediction": ["Normal", "DoW"],
    "Count": [normal_count, dow_count]
})

fig_distribution = px.pie(
    distribution,
    names="Prediction",
    values="Count",
    title="Normal vs DoW Predictions",
    hole=0.45
)

st.plotly_chart(fig_distribution, use_container_width=True)


# --------------------------------------------------
# 6. PREDICTION TREND
# --------------------------------------------------

st.header("3. Prediction Trend Over Time")

time_data = predictions.dropna(subset=["timestamp"]).copy()

if not time_data.empty:
    time_data["Time Window"] = (
        time_data["timestamp"].dt.floor("1h")
    )

    trend = (
        time_data.groupby(["Time Window", "prediction"])
        .size()
        .reset_index(name="Count")
    )

    fig_trend = px.line(
        trend,
        x="Time Window",
        y="Count",
        color="prediction",
        markers=True,
        title="Hourly Prediction Trend"
    )

    st.plotly_chart(fig_trend, use_container_width=True)

else:
    st.info("No valid timestamps are available for the trend chart.")

st.divider()


# --------------------------------------------------
# 7. RECENT DOW ALERTS
# --------------------------------------------------

st.header("4. Recent DoW Alerts")

alerts = predictions[
    predictions["prediction"].str.lower() == "dow"
].copy()

if not alerts.empty:

    alerts = alerts.sort_values(
        "timestamp",
        ascending=False
    )

    display_columns = [
        "timestamp",
        "FunctionId",
        "prediction",
        "probability",
        "actual_label"
    ]

    display_columns = [
        column for column in display_columns
        if column in alerts.columns
    ]

    st.dataframe(
        alerts[display_columns].head(20),
        use_container_width=True,
        hide_index=True
    )

    st.caption("Showing the latest 20 model-predicted DoW alerts.")

else:
    st.success("No DoW predictions found.")

st.divider()


# --------------------------------------------------
# 8. FEATURE DRIFT MONITORING
# --------------------------------------------------

st.header("5. Feature Drift Monitoring")

drift_count = (
    drift["Drift_Status"].astype(str).str.contains(
        "Drift Detected",
        case=False
    )
).sum()

no_drift_count = len(drift) - drift_count

col1, col2 = st.columns(2)

col1.metric("Features Monitored", len(drift))
col2.metric("Features with Detected Drift", int(drift_count))

fig_drift = px.bar(
    drift.sort_values("KS_Statistic", ascending=False),
    x="Feature",
    y="KS_Statistic",
    color="Drift_Status",
    title="Kolmogorov-Smirnov Feature Drift Analysis"
)

fig_drift.update_layout(
    xaxis_tickangle=-45
)

st.plotly_chart(fig_drift, use_container_width=True)

st.subheader("Feature Drift Report")

st.dataframe(
    drift,
    use_container_width=True,
    hide_index=True
)

st.divider()


# --------------------------------------------------
# 9. BASE VS ADAPTIVE MODEL COMPARISON
# --------------------------------------------------

st.header("6. Base Model vs Adaptive Model")

metrics = [
    "Accuracy",
    "Precision",
    "Recall",
    "F1_Score"
]

comparison_long = model_comparison.melt(
    id_vars="Model",
    value_vars=metrics,
    var_name="Metric",
    value_name="Score"
)

fig_comparison = px.bar(
    comparison_long,
    x="Metric",
    y="Score",
    color="Model",
    barmode="group",
    title="Held-Out Test Performance Comparison",
    text_auto=".3f"
)

fig_comparison.update_yaxes(range=[0, 1])

st.plotly_chart(
    fig_comparison,
    use_container_width=True
)

st.subheader("Model Performance Results")

st.dataframe(
    model_comparison,
    use_container_width=True,
    hide_index=True
)

st.caption(
    "These are offline held-out test results. "
    "They are separate from the simulated streaming predictions above."
)


# --------------------------------------------------
# 10. PROJECT FOOTER
# --------------------------------------------------

st.divider()

st.markdown(
    """
    **Project:** Adaptive Temporal Detection of Denial-of-Wallet Attacks

    **Pipeline:** Historical Workload → Kafka → Temporal Features →
    Sequence Builder → LSTM Inference → Drift Monitoring → Dashboard
    """
)


