
# %% [markdown]
# ============================================================
# PHASE 4: TEMPORAL FEATURE PROCESSOR
# Project: Adaptive Temporal DoW Detection
#
# Purpose:
# Calculate temporal features for incoming workload events.
# Preserve the calculations used in Notebook 01.
# ============================================================


# %% [markdown]
# STEP 1: IMPORT LIBRARIES

# %%
from collections import defaultdict, deque

import pandas as pd


# %% [markdown]
# STEP 2: TEMPORAL FEATURE PROCESSOR CLASS

# %%
class TemporalFeatureProcessor:

    def __init__(self):

        # Store previous timestamp for each function
        self.previous_timestamp = {}

        # Store current minute and its invocation count
        self.minute_tracker = {}

        # Store recent timestamps for five-minute counts
        self.recent_timestamps = defaultdict(deque)

        print("Temporal Feature Processor initialized.")


    # %% [markdown]
    # STEP 3: PROCESS ONE WORKLOAD EVENT

    # %%
    def process_event(self, event):

        # Read FunctionId
        function_id = event["FunctionId"]

        # Convert timestamp
        current_time = pd.to_datetime(
            event["timestamp"],
            utc=True
        )

        # ----------------------------------------------------
        # FEATURE 1: INTER ARRIVAL TIME
        # ----------------------------------------------------

        if function_id in self.previous_timestamp:

            inter_arrival_time = (
                current_time
                - self.previous_timestamp[function_id]
            ).total_seconds()

        else:

            inter_arrival_time = 0.0

        self.previous_timestamp[function_id] = current_time


        # ----------------------------------------------------
        # FEATURE 2 AND 3: INVOCATIONS PER MINUTE
        # ----------------------------------------------------

        current_minute = current_time.floor("min")

        if function_id not in self.minute_tracker:

            self.minute_tracker[function_id] = {
                "minute": current_minute,
                "count": 0
            }

        tracker = self.minute_tracker[function_id]

        if tracker["minute"] != current_minute:

            tracker["minute"] = current_minute
            tracker["count"] = 0

        tracker["count"] += 1

        invocations_per_minute = tracker["count"]

        function_invocations_per_minute = tracker["count"]


        # ----------------------------------------------------
        # FEATURE 4: INVOCATIONS LAST 5 MINUTES
        # ----------------------------------------------------

        timestamp_queue = self.recent_timestamps[function_id]

        five_minutes_ago = (
            current_time - pd.Timedelta(minutes=5)
        )

        # Remove events strictly older than five minutes.
        # The original notebook uses closed="both".
        while (
            timestamp_queue
            and timestamp_queue[0] < five_minutes_ago
        ):

            timestamp_queue.popleft()

        # Include current event
        timestamp_queue.append(current_time)

        invocations_last_5min = len(timestamp_queue)


        # ----------------------------------------------------
        # FEATURE 5: TOTAL DELAY
        # ----------------------------------------------------

        total_delay = (
            float(event["InvocationDelay"])
            + float(event["ResponseDelay"])
        )


        # ----------------------------------------------------
        # FEATURE 6: TOTAL PROCESSING TIME
        # ----------------------------------------------------

        total_processing_time = (
            float(event["InvocationDelay"])
            + float(event["FunctionDuration"])
            + float(event["ResponseDelay"])
        )


        # ----------------------------------------------------
        # FEATURE 7: ACTIVE FUNCTION CHANGE
        # ----------------------------------------------------

        active_function_change = (
            float(event["ActiveFunctionsAtResponse"])
            - float(event["ActiveFunctionsAtRequest"])
        )


        # ----------------------------------------------------
        # FEATURE 8: CPU SPREAD
        # ----------------------------------------------------

        cpu_spread = (
            float(event["maxcpu"])
            - float(event["avgcpu"])
        )


        # ----------------------------------------------------
        # STEP 4: ADD FEATURES TO EVENT
        # ----------------------------------------------------

        processed_event = event.copy()

        processed_event.update({

            "InterArrivalTime": inter_arrival_time,

            "InvocationsPerMinute": invocations_per_minute,

            "FunctionInvocationsPerMinute":
                function_invocations_per_minute,

            "InvocationsLast5Min": invocations_last_5min,

            "TotalDelay": total_delay,

            "TotalProcessingTime": total_processing_time,

            "ActiveFunctionChange": active_function_change,

            "CPU_Spread": cpu_spread

        })

        return processed_event


# %% [markdown]
# STEP 5: TEST USING THE ORIGINAL DATASET
#
# We process only the first 10 chronological events.
# This is a feature-engineering test, not model inference.

# %%
def main():

    DATA_PATH = "data/raw/dataset.csv"

    print("\nLoading dataset...")

    df = pd.read_csv(DATA_PATH)

    # Match original notebook timestamp processing
    df["timestamp"] = pd.to_datetime(
        df["timestamp"],
        errors="coerce",
        utc=True
    )

    df = df.dropna(
        subset=["timestamp"]
    )

    # Match original chronological ordering
    df = df.sort_values(
        ["timestamp", "Id"]
    ).reset_index(drop=True)

    print("Valid records:", len(df))

    processor = TemporalFeatureProcessor()

    print("\nProcessing first 10 events...\n")

    results = []

    for _, row in df.head(10).iterrows():

        event = row.to_dict()

        event["timestamp"] = (
            row["timestamp"].isoformat()
        )

        processed_event = processor.process_event(event)

        results.append(processed_event)

        print(
            "FunctionId:", processed_event["FunctionId"],
            "| InterArrivalTime:",
            processed_event["InterArrivalTime"],
            "| InvocationsLast5Min:",
            processed_event["InvocationsLast5Min"],
            "| TotalDelay:",
            processed_event["TotalDelay"]
        )

    # Display feature results
    result_df = pd.DataFrame(results)

    print("\nENGINEERED FEATURE RESULTS")

    display_columns = [
        "FunctionId",
        "InterArrivalTime",
        "InvocationsPerMinute",
        "FunctionInvocationsPerMinute",
        "InvocationsLast5Min",
        "TotalDelay",
        "TotalProcessingTime",
        "ActiveFunctionChange",
        "CPU_Spread"
    ]

    print(result_df[display_columns].to_string(index=False))

    print("\nPHASE 4 FEATURE PROCESSING TEST COMPLETED.")


# %% [markdown]
# STEP 6: RUN PROGRAM

# %%
if __name__ == "__main__":
    main()
