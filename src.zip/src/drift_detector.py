import pandas as pd
from scipy.stats import ks_2samp

# --------------------------------------------------
# 1. Load reference data
# --------------------------------------------------

reference_path = "data/processed/drift_reference.csv"

reference_df = pd.read_csv(reference_path)

# --------------------------------------------------
# 2. Create a simulated incoming batch
# --------------------------------------------------

# For initial testing, use another sample from the
# training dataset. This is a pipeline test, not
# evidence of real workload drift.

training_df = pd.read_csv(
    "data/processed/train_chronological.csv"
)

FEATURE_COLUMNS = list(reference_df.columns)

current_df = training_df[FEATURE_COLUMNS].sample(
    n=2000,
    random_state=100
)

# --------------------------------------------------
# 3. Perform KS drift detection
# --------------------------------------------------

results = []

for feature in FEATURE_COLUMNS:

    reference_values = reference_df[feature].dropna()
    current_values = current_df[feature].dropna()

    statistic, p_value = ks_2samp(
        reference_values,
        current_values
    )

    if p_value < 0.05:
        drift_status = "Drift Detected"
    else:
        drift_status = "No Drift"

    results.append({
        "Feature": feature,
        "KS_Statistic": statistic,
        "P_Value": p_value,
        "Drift_Status": drift_status
    })

# --------------------------------------------------
# 4. Create results table
# --------------------------------------------------

results_df = pd.DataFrame(results)

results_df = results_df.sort_values(
    "KS_Statistic",
    ascending=False
)

print("\n" + "=" * 60)
print("FEATURE DRIFT DETECTION RESULTS")
print("=" * 60)

print(results_df.to_string(index=False))

# --------------------------------------------------
# 5. Overall drift summary
# --------------------------------------------------

drift_count = (
    results_df["Drift_Status"] == "Drift Detected"
).sum()

print("\nTOTAL FEATURES:", len(results_df))
print("DRIFTED FEATURES:", drift_count)
print("NON-DRIFTED FEATURES:", len(results_df) - drift_count)

# --------------------------------------------------
# 6. Save report
# --------------------------------------------------

results_df.to_csv(
    "results/feature_drift_report.csv",
    index=False
)

print("\nDrift report saved successfully.")

print("\nPHASE 6.2 TEST COMPLETED.")