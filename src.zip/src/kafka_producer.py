
# %% [markdown]
# ============================================================
# PHASE 3: KAFKA PRODUCER
# Project: Denial-of-Wallet Attack Detection
# Purpose: Send historical workload events to Kafka
# ============================================================

# %% [markdown]
# STEP 1: IMPORT REQUIRED LIBRARIES

# %%
import json
import time
import pandas as pd

from kafka import KafkaProducer


# %% [markdown]
# STEP 2: CONFIGURATION

# %%
DATA_PATH = "data/raw/dataset.csv"

KAFKA_SERVER = "localhost:9092"
TOPIC_NAME = "workload-events"

MAX_EVENTS = 10000
REPLAY_DELAY_SECONDS = 0.0


# %% [markdown]
# STEP 3: LOAD AND PREPARE THE DATASET

# %%
def load_workload_data():

    print("Loading workload dataset...")

    df = pd.read_csv(DATA_PATH)

    print("Original records:", len(df))

    # Convert timestamps to UTC
    df["timestamp"] = pd.to_datetime(
        df["timestamp"],
        errors="coerce",
        utc=True
    )

    # Remove invalid timestamps
    df = df.dropna(subset=["timestamp"])

    # Sort events chronologically
    df = df.sort_values(
    by=["timestamp", "Id"]
).reset_index(drop=True)
    print("Valid records:", len(df))
    print("Chronological sorting completed.")

    return df


# %% [markdown]
# STEP 4: CONVERT DATASET ROWS INTO KAFKA EVENTS

# %%
def convert_row_to_event(row):

    event = row.to_dict()

    for key, value in event.items():

        # Convert missing values to None
        if pd.isna(value):
            event[key] = None

        # Convert timestamps into strings
        elif isinstance(value, pd.Timestamp):
            event[key] = value.isoformat()

        # Convert NumPy scalar values into Python values
        elif hasattr(value, "item"):
            event[key] = value.item()

    return event


# %% [markdown]
# STEP 5: CONNECT TO KAFKA

# %%
def create_kafka_producer():

    producer = KafkaProducer(
        bootstrap_servers=KAFKA_SERVER,

        value_serializer=lambda value: json.dumps(
            value
        ).encode("utf-8"),

        retries=5
    )

    print("Connected to Kafka successfully.")

    return producer


# %% [markdown]
# STEP 6: SEND WORKLOAD EVENTS TO KAFKA

# %%
def send_workload_events(producer, df):

    total_sent = 0

    print("\nStarting workload event streaming...\n")

    for _, row in df.head(MAX_EVENTS).iterrows():

        event = convert_row_to_event(row)

        # Send event to Kafka topic
        future = producer.send(
            TOPIC_NAME,
            value=event
        )

        # Wait for broker acknowledgement
        metadata = future.get(timeout=10)

        total_sent += 1

        print(
            f"Event {total_sent} sent | "
            f"Topic: {metadata.topic} | "
            f"Partition: {metadata.partition} | "
            f"Offset: {metadata.offset} | "
            f"FunctionId: {event['FunctionId']}"
        )

        if REPLAY_DELAY_SECONDS > 0:
            time.sleep(REPLAY_DELAY_SECONDS)

    producer.flush()

    print("\nTotal events sent:", total_sent)


# %% [markdown]
# STEP 7: MAIN EXECUTION

# %%
def main():

    producer = None

    try:

        df = load_workload_data()

        producer = create_kafka_producer()

        send_workload_events(
            producer,
            df
        )

        print("\nKAFKA PRODUCER COMPLETED SUCCESSFULLY.")

    except Exception as error:

        print("\nERROR:", error)

        raise

    finally:

        if producer is not None:
            producer.close()

            print("Kafka producer connection closed.")


# %% [markdown]
# STEP 8: RUN THE PROGRAM

# %%
if __name__ == "__main__":
    main()

# %%
