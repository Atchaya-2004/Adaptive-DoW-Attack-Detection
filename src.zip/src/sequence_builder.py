
import numpy as np
import pandas as pd
from collections import defaultdict, deque


class SequenceBuilder:

    def __init__(self, sequence_length=30, max_time_gap=3600):

        self.sequence_length = sequence_length
        self.max_time_gap = max_time_gap

        # Store separate event histories for each FunctionId
        self.feature_buffers = defaultdict(
            lambda: deque(maxlen=self.sequence_length)
        )

        self.label_buffers = defaultdict(
            lambda: deque(maxlen=self.sequence_length)
        )

        self.last_timestamps = {}

        print("Sequence Builder initialized.")

    def add_event(
        self,
        function_id,
        timestamp,
        processed_features,
        label=None
    ):

        # Convert timestamp
        timestamp = pd.to_datetime(timestamp, utc=True)

        # Convert processed features into NumPy array
        processed_features = np.asarray(
            processed_features,
            dtype=np.float32
        ).reshape(-1)

        # Validate feature count
        if len(processed_features) != 26:
            raise ValueError(
                f"Expected 26 features, received {len(processed_features)}"
            )

        # Check time gap for this FunctionId
        if function_id in self.last_timestamps:

            previous_timestamp = self.last_timestamps[function_id]

            time_gap = (
                timestamp - previous_timestamp
            ).total_seconds()

            # Reset sequence if gap exceeds one hour
            if time_gap > self.max_time_gap:

                self.feature_buffers[function_id].clear()
                self.label_buffers[function_id].clear()

        # Store current event
        self.feature_buffers[function_id].append(
            processed_features
        )

        self.label_buffers[function_id].append(label)

        self.last_timestamps[function_id] = timestamp

        # Wait until 30 events are collected
        if len(self.feature_buffers[function_id]) < self.sequence_length:
            return None

        # Construct sequence
        sequence = np.stack(
            list(self.feature_buffers[function_id])
        )

        # Label of the last event in the sequence
        sequence_label = self.label_buffers[function_id][-1]

        return sequence, sequence_label


# ============================================================
# TESTING
# ============================================================

def main():

    print("\nTesting Sequence Builder...\n")

    builder = SequenceBuilder(
        sequence_length=30,
        max_time_gap=3600
    )

    function_id = 100

    timestamp = pd.Timestamp(
        "2024-01-01 10:00:00",
        tz="UTC"
    )

    sequences_created = 0

    # Generate 35 dummy events for structural testing
    for i in range(35):

        event_timestamp = timestamp + pd.Timedelta(
            seconds=i * 10
        )

        # Dummy 26-feature vector
        features = np.random.rand(26).astype(np.float32)

        # Dummy binary label
        label = i % 2

        result = builder.add_event(
            function_id=function_id,
            timestamp=event_timestamp,
            processed_features=features,
            label=label
        )

        if result is not None:

            sequence, sequence_label = result

            sequences_created += 1

            print(
                f"Sequence {sequences_created} created | "
                f"Shape: {sequence.shape} | "
                f"Label: {sequence_label}"
            )

    print("\nTEST RESULTS")
    print("------------------------------")
    print("Events processed:", 35)
    print("Sequences created:", sequences_created)
    print("Expected sequences:", 6)

    if sequences_created == 6:
        print("\nSEQUENCE BUILDER TEST PASSED.")
    else:
        print("\nSEQUENCE BUILDER TEST FAILED.")


if __name__ == "__main__":
    main()
