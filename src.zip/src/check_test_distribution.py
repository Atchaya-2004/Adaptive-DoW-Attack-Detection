import numpy as np

y_test = np.load("data/processed/sequences/y_test.npy")

print("\nTEST DATASET DISTRIBUTION")
print("Total test sequences:", len(y_test))

unique, counts = np.unique(y_test, return_counts=True)

for label, count in zip(unique, counts):
    class_name = "DoW" if label == 1 else "Normal"
    percentage = (count / len(y_test)) * 100

    print(
        f"{class_name}: {count} "
        f"({percentage:.2f}%)"
    )