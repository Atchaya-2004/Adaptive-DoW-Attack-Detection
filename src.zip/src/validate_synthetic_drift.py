
import os
import pandas as pd
from scipy.stats import ks_2samp

print("=" * 60)
print("PHASE 6.3 - SYNTHETIC DRIFT VALIDATION")
print("=" * 60)

# Step 1: Load the original reference dataset
reference_df = pd.read_csv(
    "data/processed/drift_reference.csv"
)

print("\nReference dataset loaded.")
print("Reference records:", len(reference_df))

# Step 2: Create a separate synthetic dataset
synthetic_df = reference_df.sample(
    n=2000,
    replace=True,
    random_state=42
).copy()

# Step 3: Introduce artificial distribution shifts
# These changes are only applied to the synthetic dataset.

synthetic_df["CPU_Spread"] = (
    synthetic_df["CPU_Spread"] * 1.5
)

synthetic_df["RTT"] = (
    synthetic_df["RTT"] * 1.3
)

synthetic_df["FunctionDuration"] = (
    synthetic_df["FunctionDuration"] * 1.4
)

print("\nArtificial drift introduced in:")
print("- CPU_Spread")
print("- RTT")
print("- FunctionDuration")

# Step 4: Compare reference and synthetic distributions
results = []

for feature in reference_df.columns:

    reference_values = reference_df[feature].dropna()
    synthetic_values = synthetic_df[feature].dropna()

    ks_statistic, p_value = ks_2samp(
        reference_values,
        synthetic_values
    )

    if p_value < 0.05:
        status = "Drift Detected"
    else:
        status = "No Drift"

    results.append({
        "Feature": feature,
        "KS_Statistic": round(ks_statistic, 4),
        "P_Value": round(p_value, 6),
        "Drift_Status": status
    })

# Step 5: Display results
report_df = pd.DataFrame(results)

report_df = report_df.sort_values(
    by="KS_Statistic",
    ascending=False
)

print("\n" + "=" * 60)
print("SYNTHETIC DRIFT VALIDATION RESULTS")
print("=" * 60)

print(report_df.to_string(index=False))

drifted_count = (
    report_df["Drift_Status"] == "Drift Detected"
).sum()

print("\nTOTAL FEATURES:", len(report_df))
print("DRIFTED FEATURES:", drifted_count)
print(
    "NON-DRIFTED FEATURES:",
    len(report_df) - drifted_count
)

# Step 6: Save a separate report
os.makedirs("results", exist_ok=True)

report_df.to_csv(
    "results/synthetic_drift_validation.csv",
    index=False
)

print("\nSynthetic drift report saved successfully.")

# Step 7: Validate expected detection
expected_features = [
    "CPU_Spread",
    "RTT",
    "FunctionDuration"
]

detected_features = report_df[
    report_df["Drift_Status"] == "Drift Detected"
]["Feature"].tolist()

for feature in expected_features:
    if feature in detected_features:
        print(feature, "-> Successfully detected")
    else:
        print(feature, "-> Not detected")

print("\nPHASE 6.3 TEST COMPLETED.")
