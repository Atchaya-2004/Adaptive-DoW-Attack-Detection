
import json
import os
import csv
from collections import defaultdict, deque

import numpy as np
import pandas as pd
import joblib
import tensorflow as tf

from kafka import KafkaConsumer


# --------------------------------------------------
# 1. PROJECT PATHS AND MODEL CONFIGURATION
# --------------------------------------------------

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

PREPROCESSOR_PATH = os.path.join(
    BASE_DIR, "models", "preprocessor.joblib"
)

MODEL_PATH = os.path.join(
    BASE_DIR, "models", "selected_adaptive_model.keras"
)

RESULTS_DIR = os.path.join(BASE_DIR, "results")

PREDICTIONS_CSV = os.path.join(
    RESULTS_DIR, "streaming_predictions.csv"
)

SEQUENCE_LENGTH = 30
MAX_TIME_GAP = 3600
PREDICTION_THRESHOLD = 0.5

os.makedirs(RESULTS_DIR, exist_ok=True)


# --------------------------------------------------
# 2. RAW MODEL INPUT FEATURES
# --------------------------------------------------

FEATURE_COLUMNS = [
    "RTT",
    "InvocationDelay",
    "ResponseDelay",
    "FunctionDuration",
    "ActiveFunctionsAtRequest",
    "ActiveFunctionsAtResponse",
    "maxcpu",
    "avgcpu",
    "p95maxcpu",
    "vmcorecountbucket",
    "vmmemorybucket",
    "InterArrivalTime",
    "FunctionInvocationsPerMinute",
    "InvocationsLast5Min",
    "TotalDelay",
    "TotalProcessingTime",
    "ActiveFunctionChange",
    "CPU_Spread",
    "functionTrigger",
    "vmcategory"
]


# --------------------------------------------------
# 3. LOAD SAVED PREPROCESSOR AND MODEL
# --------------------------------------------------

print("Loading saved preprocessor...")

preprocessor = joblib.load(PREPROCESSOR_PATH)

print("Preprocessor loaded successfully.")

print("Loading saved LSTM model...")

model = tf.keras.models.load_model(MODEL_PATH)

print("LSTM model loaded successfully.")

print("Model input shape:", model.input_shape)
print("SCRIPT FILE:", os.path.abspath(__file__))
print("CSV FILE:", os.path.abspath(PREDICTIONS_CSV))
print("CSV EXISTS:", os.path.exists(PREDICTIONS_CSV))

# --------------------------------------------------
# 4. TEMPORAL FEATURE STORAGE
# --------------------------------------------------

previous_timestamp = {}

minute_counts = defaultdict(int)

recent_events = defaultdict(deque)

sequence_buffers = defaultdict(
    lambda: deque(maxlen=SEQUENCE_LENGTH)
)

last_sequence_timestamp = {}


# --------------------------------------------------
# 5. TEMPORAL FEATURE ENGINEERING
# --------------------------------------------------

def process_temporal_features(event):

    function_id = event["FunctionId"]

    current_time = pd.to_datetime(
        event["timestamp"], utc=True
    )

    current_seconds = current_time.timestamp()

    # Inter-arrival time
    if function_id in previous_timestamp:

        inter_arrival = (
            current_seconds - previous_timestamp[function_id]
        )

        if inter_arrival < 0:
            raise ValueError("Events are not chronological.")

    else:
        inter_arrival = 0.0

    previous_timestamp[function_id] = current_seconds

    # Per-function invocation count within the current minute
    minute_key = (
        function_id,
        current_time.floor("min")
    )

    minute_counts[minute_key] += 1

    function_invocations_per_minute = minute_counts[minute_key]

    # Rolling five-minute invocation count
    event_queue = recent_events[function_id]

    five_minutes = 300

    while event_queue:

        oldest_time = event_queue[0]

        if (current_seconds - oldest_time) > five_minutes:
            event_queue.popleft()
        else:
            break

    event_queue.append(current_seconds)

    invocations_last_5min = len(event_queue)

    # Engineered features
    event["InterArrivalTime"] = inter_arrival

    event["FunctionInvocationsPerMinute"] = (
        function_invocations_per_minute
    )

    event["InvocationsLast5Min"] = invocations_last_5min

    event["TotalDelay"] = (
        float(event["InvocationDelay"])
        + float(event["ResponseDelay"])
    )

    event["TotalProcessingTime"] = (
        float(event["InvocationDelay"])
        + float(event["FunctionDuration"])
        + float(event["ResponseDelay"])
    )

    event["ActiveFunctionChange"] = (
        float(event["ActiveFunctionsAtResponse"])
        - float(event["ActiveFunctionsAtRequest"])
    )

    event["CPU_Spread"] = (
        float(event["maxcpu"])
        - float(event["avgcpu"])
    )

    return event, current_seconds


# --------------------------------------------------
# 6. PREPROCESS ONE EVENT
# --------------------------------------------------

def preprocess_event(event):

    input_data = {}

    for column in FEATURE_COLUMNS:
        input_data[column] = event[column]

    input_df = pd.DataFrame([input_data])

    transformed = preprocessor.transform(input_df)

    if hasattr(transformed, "toarray"):
        transformed = transformed.toarray()

    return np.asarray(
        transformed,
        dtype=np.float32
    ).reshape(-1)


# --------------------------------------------------
# 7. BUILD SEQUENCES AND PREDICT
# --------------------------------------------------

def process_event(event):

    function_id = event["FunctionId"]

    event, current_seconds = process_temporal_features(event)

    # Reset sequence if the time gap exceeds one hour
    if function_id in last_sequence_timestamp:

        time_gap = (
            current_seconds - last_sequence_timestamp[function_id]
        )

        if time_gap > MAX_TIME_GAP:
            sequence_buffers[function_id].clear()

    last_sequence_timestamp[function_id] = current_seconds

    # Transform raw event into 26 model features
    feature_vector = preprocess_event(event)

    if len(feature_vector) != 26:
        raise ValueError(
            f"Expected 26 features, received {len(feature_vector)}"
        )

    sequence_buffers[function_id].append(feature_vector)

    # Wait until 30 events are available
    if len(sequence_buffers[function_id]) < SEQUENCE_LENGTH:
        return None

    sequence = np.array(
        sequence_buffers[function_id],
        dtype=np.float32
    )

    sequence = np.expand_dims(sequence, axis=0)

    probability = float(
        model.predict(sequence, verbose=0)[0][0]
    )

    prediction = (
        1 if probability >= PREDICTION_THRESHOLD else 0
    )

    label = "DoW" if prediction == 1 else "Normal"

    return {
        "timestamp": event.get("timestamp"),
        "FunctionId": function_id,
        "prediction": label,
        "probability": probability,
        "actual_label": event.get("bot")
    }





# --------------------------------------------------
# 9. CONNECT TO KAFKA
# --------------------------------------------------

print("\nConnecting to Kafka...")

consumer = KafkaConsumer(
    "workload-events",
    bootstrap_servers=["localhost:9092"],
    auto_offset_reset="latest",
    enable_auto_commit=True,
    group_id="dow-streaming-inference-v2",
    value_deserializer=lambda value: json.loads(
        value.decode("utf-8")
    )
)

print("Connected to Kafka successfully.")

print("\nWaiting for workload events...")
print("Press CTRL + C to stop.\n")


# --------------------------------------------------
# 10. STREAMING PREDICTION LOOP
# --------------------------------------------------


# --------------------------------------------------
# 10. STREAMING PREDICTION LOOP WITH CSV LOGGING
# --------------------------------------------------

RESULTS_DIR = os.path.join(BASE_DIR, "results")
os.makedirs(RESULTS_DIR, exist_ok=True)

PREDICTIONS_CSV = os.path.join(
    RESULTS_DIR,
    "streaming_predictions.csv"
)

CSV_FIELDS = [
    "timestamp",
    "FunctionId",
    "prediction",
    "probability",
    "actual_label"
]

events_received = 0
predictions_made = 0
dow_alerts = 0

print("\nConnecting to Kafka...")
print("Prediction CSV:", PREDICTIONS_CSV)

# Open the CSV once and keep it open while processing.
try:
    with open(
        PREDICTIONS_CSV,
        mode="w",
        newline="",
        encoding="utf-8"
    ) as csv_file:

        csv_writer = csv.DictWriter(
            csv_file,
            fieldnames=CSV_FIELDS
        )

        # Write the column names.
        csv_writer.writeheader()
        csv_file.flush()

        print("CSV file created successfully.")
        print("Waiting for workload events...")
        print("Press CTRL + C to stop.\n")

        try:
            for message in consumer:

                event = message.value

                try:
                    result = process_event(event)
                    events_received += 1

                    if result is not None:

                        # Save prediction immediately.
                        csv_writer.writerow(result)
                        csv_file.flush()

                        predictions_made += 1

                        if result["prediction"] == "DoW":
                            dow_alerts += 1

                        print("\n------------------------------")
                        print("STREAMING PREDICTION")
                        print("------------------------------")
                        print("Function ID:", result["FunctionId"])
                        print("Prediction:", result["prediction"])
                        print(
                            "DoW Probability:",
                            round(result["probability"], 4)
                        )
                        print("Actual Label:", result["actual_label"])

                        if result["prediction"] == "DoW":
                            print("!!! DoW ALERT !!!")

                except Exception as error:
                    print("Event processing error:", error)

        except KeyboardInterrupt:
            print("\nStopping streaming inference...")

finally:
    consumer.close()

print("\nSTREAMING SUMMARY")
print("------------------------------")
print("Events received:", events_received)
print("Predictions made:", predictions_made)
print("DoW alerts:", dow_alerts)
print("Prediction CSV:", PREDICTIONS_CSV)
print("CSV rows saved:", predictions_made)
print("CSV file exists:", os.path.exists(PREDICTIONS_CSV))

print("\nStreaming inference stopped.")
