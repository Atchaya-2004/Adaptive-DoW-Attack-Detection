import os
import pandas as pd

# --------------------------------------------------
# 1. Define numerical features used by the model
# --------------------------------------------------

FEATURE_COLUMNS = [
    "RTT",
    "InvocationDelay",
    "ResponseDelay",
    "FunctionDuration",
    "ActiveFunctionsAtRequest",
    "ActiveFunctionsAtResponse",
    "maxcpu",
    "avgcpu",
    "p95maxcpu",
    "vmcorecountbucket",
    "vmmemorybucket",
    "InterArrivalTime",
    "FunctionInvocationsPerMinute",
    "InvocationsLast5Min",
    "TotalDelay",
    "TotalProcessingTime",
    "ActiveFunctionChange",
    "CPU_Spread"
]

# --------------------------------------------------
# 2. Load existing training data
# --------------------------------------------------

input_path = "data/processed/train_chronological.csv"

df = pd.read_csv(input_path)

print("Training data loaded.")
print("Original shape:", df.shape)

# --------------------------------------------------
# 3. Verify required features
# --------------------------------------------------

missing_columns = []

for column in FEATURE_COLUMNS:
    if column not in df.columns:
        missing_columns.append(column)

if missing_columns:
    print("\nMissing required features:")
    print(missing_columns)
    raise ValueError("Required drift features are missing.")

# --------------------------------------------------
# 4. Select numerical features
# --------------------------------------------------

reference_df = df[FEATURE_COLUMNS].copy()

# Convert values to numeric
for column in FEATURE_COLUMNS:
    reference_df[column] = pd.to_numeric(
        reference_df[column],
        errors="coerce"
    )

# Remove invalid values
reference_df = reference_df.dropna()

# --------------------------------------------------
# 5. Select a representative reference sample
# --------------------------------------------------

sample_size = min(10000, len(reference_df))

reference_sample = reference_df.sample(
    n=sample_size,
    random_state=42
)

# --------------------------------------------------
# 6. Save reference data
# --------------------------------------------------

output_path = "data/processed/drift_reference.csv"

os.makedirs("data/processed", exist_ok=True)

reference_sample.to_csv(
    output_path,
    index=False
)

# --------------------------------------------------
# 7. Display results
# --------------------------------------------------

print("\n" + "=" * 50)
print("DRIFT REFERENCE DATA PREPARATION")
print("=" * 50)

print("Original training records:", len(df))
print("Valid reference records:", len(reference_df))
print("Reference sample size:", len(reference_sample))
print("Number of features:", len(FEATURE_COLUMNS))

print("\nReference feature summary:")
print(reference_sample.describe().round(3))

print("\nReference dataset saved:")
print(output_path)

print("\nPHASE 6.1 COMPLETED.")